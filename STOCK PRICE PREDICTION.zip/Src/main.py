import streamlit as st
import streamlit.components as stc
from datetime import date
import yfinance as yf
from fbprophet import Prophet
from fbprophet.plot import plot_plotly
from plotly import graph_objs as go
import time
import socket
import base64
timestr= time.strftime("%Y%m%d-%H%M%S")


start=time.time()

START = "2015-01-01"    
TODAY = date.today().strftime("%Y-%m-%d")

_, col2, _ = st.columns([1, 2 , 1])

with col2:
    st.title("STOCKIFY")


stocks = ('GOOG', 'AAPL', 'MSFT','TCS','BHARTIARTL.NS','ONGC.NS','NMDC.NS')  
st.text("")
selected_stock = st.selectbox('Select dataset for prediction', stocks)
st.text("")
n_years = st.slider('Years of prediction:', 1, 9)
period = n_years * 365  


@st.cache
def load_data(ticker):
    data = yf.download(ticker, START, TODAY)
    data.reset_index(inplace=True)
    return data

       
data_load_state = st.text('Loading data...')
data = load_data(selected_stock)
data_load_state.text('Loading data... done!')

st.subheader('Raw data')
st.write(data.tail())

# Plot raw data
def plot_raw_data():
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=data['Date'], y=data['Open'], name="stock_open"))
    fig.add_trace(go.Scatter(x=data['Date'], y=data['Close'], name="stock_close"))
    fig.layout.update(title_text='Time Series data with Rangeslider', xaxis_rangeslider_visible=True)
    st.plotly_chart(fig)
       
plot_raw_data()

# Predict forecast with Prophet.
df_train = data[['Date','Close']]
df_train = df_train.rename(columns={"Date": "ds", "Close": "y"})

m = Prophet()
m.fit(df_train)
future = m.make_future_dataframe(periods=period)
forecast = m.predict(future)

# Show and plot forecast
_, col2, _ = st.columns([1, 2 , 1])

with col2:
    st.title("Forecast data")
st.write(forecast.tail())
       
st.write(f'Forecast plot for {n_years} years')
fig1 = plot_plotly(m, forecast)
st.plotly_chart(fig1)
st.text("")
fig2 = m.plot_components(forecast)
st.write(fig2)




def text_downloader(raw_text):
    b64=base64.b64encode(raw_text.encode()).decode()
    new_filename="new_text_file){}.txt".format(timestr)
    st.markdown("## Download File ##")
    href=f'<a href="data:file/txt;base64,{b64}" download="{new_filename}"> Click Here!! </a>'
    st.markdown(href,unsafe_allow_html=True)
     
       
               
my_text=st.text_area("Your message:")
if st.button("Save"):
    st.write(my_text)
    text_downloader(my_text)  
       
       

end=time.time()

st.text("" )
hostname = socket.gethostname()
IPAddr = socket.gethostbyname(hostname)
st.write("Your IP Address is:",IPAddr)
st.text(" ")
st.write("Time taken to run the program is:", end-start,"seconds..")
