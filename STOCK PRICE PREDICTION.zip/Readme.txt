In a financially volatile market, as the stock market, it is important to have a very precise prediction of a future trend.
 Because of the financial crisis and scoring profits, it is mandatory to have a secure prediction of the values of the stocks.
 Stock market price data is generated in huge volume and it changes every second. 
In order to overcome this problem we are introducing our web app "Stockify" for predicting the stock prices for your desired input stock's and for year ranges.
